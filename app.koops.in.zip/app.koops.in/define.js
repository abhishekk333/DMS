/*
 |-----------------------------------------------
 | javascript vars
 |-----------------------------------------------
 |
 */
var rootname = "";
var baseUrl = window.location.origin + rootname;

var appUrl = baseUrl + "/application";
var companyUrl = baseUrl + "/company";
var serverUrl = baseUrl + "/server";
var uploadUrl = baseUrl + "/upload";
var customerUrl = baseUrl + "/customer";
var mobileSalesUrl = baseUrl + "/mobileSales";

var cookiePath = rootname ? rootname : "/";

function getCookieDomain() {
    const hostName = window.location.hostname;
    return !rootname ? hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1) + 1) : "";
}
var cookieDomain = getCookieDomain();

var DEBUG = false;

const requestTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone == 'Asia/Calcutta' ? 'Asia/Kolkata' : Intl.DateTimeFormat().resolvedOptions().timeZone;