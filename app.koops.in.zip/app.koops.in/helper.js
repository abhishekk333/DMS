// make cookie object
function makeCookieObject(data) {

    var obj = {};

    obj._ksld = {
        _ksat: data.access_token,
        _ksrt: data.refresh_token,
        _kstt: data.token_type,
        _ksei: data.expires_in
    }
    obj._ksud = {
        _ksuserid: data.profile.user_id,
        _ksglobaluserid: data.profile.global_user_id,
        _ksname: data.profile.name,
        _ksprofilepic: data.profile.profile_pic,
        _ksemail: data.profile.email,
        _ksregisteredno: data.profile.registered_no,
        _ksloginvia: data.profile.login_via,
        _ksusername: data.profile.username,
        _ksusergroup: data.profile.user_group,
        _kscompanyname: data.company.name,
        _kscustomerid: data.customer_id,
        _kscurrency: data.currency,
        _kscurrencydecimalcode: data.currency_decimal_code,
    }
    return obj;
}

var old_console_log = console.log;

console.log = function(...arg) {
    if (DEBUG) {
        old_console_log(...arg);
    }
}